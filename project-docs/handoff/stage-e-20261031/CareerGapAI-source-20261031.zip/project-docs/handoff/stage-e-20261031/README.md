# Bàn giao localhost — release20261031

Đã đồng bộ A12 (lỗi reset cụ thể và nút yêu cầu link mới) cùng chức năng xem kết quả cặp đã lưu từ30/10. Demo5190 dùng **Fake/Synthetic**, không nạp.env hoặc gọi provider thật. **M6 pending_external_review**, đánh giá ngoài đang hoãn.

- [Hướng dẫn dùng thử](huong-dan-dung-thu.md)
- [Vận hành, backup và rollback](van-hanh-local.md)
- [Cẩm nang bảo vệ](thuyet-trinh.md)
- [Trạng thái M6](nghiem-thu-M6.md)
- [Ảnh/video mới](demo.html)
- [Source ZIP31](CareerGapAI-source-20261031.zip), kèm `SOURCE-MANIFEST.json` trong ZIP
- [Verification receipt](verification.json)
- [Biên bản phát hành](../../report/handoff-sync-2026-10-31.md)

Regression riêng: backend160/160, frontend15/15, E2E22/22, lint/typecheck/build đạt. UI trên runtime5190 kiểm history qua reload và reset invalid→forgot, không intercept. Rollback30→31/fault31/recover31 đạt; backup restore43bảng/7objects/DPkeys khớp. Không gán test này thành chất lượng AI hoặc phản hồi giảng viên.

Runtime31 ở `.local/handoff-demo-20261029/releases/20261031/runtime`; dữ liệu/accounts/storage vẫn tại vùng demo29. Runtime29/30 và gói27/29/30 được giữ nguyên. ZIP nguồn không chứa runtime/DB/accounts hoặc corpus private; rollback trên máy hiện tại dùng runtime cũ đã giữ, không build source31 dưới nhãn cũ trên máy mới.

Slide và video nền29/10 ở [bộ nền](../stage-e-20261029/README.md) giữ nguyên phiên bản; ảnh reset/video history31 là bằng chứng mới. Phiếu dùng thử trong bộ này là mẫu trống, không phải phản hồi bên ngoài.

# topcv DESIGN.md

> Auto-generated design system — reverse-engineered via static analysis by skillui.
> Frameworks: None detected
> Colors: 20 · Fonts: 2 · Components: 0
> Icon library: not detected · State: not detected
> Primary theme: dark · Dark mode toggle: no · Motion: expressive

---

## 1. Visual Theme & Atmosphere

This is a **dark-themed** interface with a neutral tone. Depth is expressed through layered shadows and subtle surface color variation. Typography pairs **inherit** for display/headings with **Arial** for body text, creating clear visual hierarchy through type contrast. Spacing follows a **5px base grid** (standard density), with scale: 5, 10, 15, 20, 25, 30, 35, 40px. Motion is expressive — spring physics, layout animations, and staggered reveals are part of the visual language.

---

## 2. Color Palette & Roles

| Token | Hex | Role | Use |
|---|---|---|---|
| bs-table-striped-color | `#000000` | background | Page background, darkest surface |
| bs-body-color | `#212529` | surface | Card and panel backgrounds |
| bs-table-striped-color | `#ffffff` | text-primary | Headings and body text |
| bs-secondary | `#6c757d` | text-muted | Captions, placeholders, secondary info |
| border | `#5c636a` | border | Dividers, card borders, outlines |
| danger | `#dc3545` | danger | Error states, destructive actions |
| success | `#00b14f` | success | Success states, positive indicators |
| warning | `#ffc107` | warning | Warning states, caution indicators |
| bs-primary | `#0d6efd` | info | Informational highlights |
| unknown | `#198754` | unknown | Palette color |
| unknown | `#dee2e6` | unknown | Palette color |
| unknown | `#e9ecef` | unknown | Palette color |
| unknown | `#0dcaf0` | unknown | Palette color |
| unknown | `#0a58ca` | unknown | Palette color |
| unknown | `#999999` | unknown | Palette color |
| unknown | `#41464b` | unknown | Palette color |
| unknown | `#51585e` | unknown | Palette color |
| unknown | `#191c1f` | unknown | Palette color |
| unknown | `#373b3e` | unknown | Palette color |
| unknown | `#adb5bd` | unknown | Palette color |

### CSS Variable Tokens

```css
--bs-primary: #0d6efd;
--bs-secondary: #6c757d;
--bs-primary-rgb: 13,110,253;
--bs-secondary-rgb: 108,117,125;
--bs-table-accent-bg: transparent;
```


---

## 3. Typography Rules

**Font Stack:**
- **Arial** — Heading 1, Heading 2, Heading 3
- **inherit** — Body, Caption

| Role | Font | Size | Weight |
|---|---|---|---|
| Heading 1 | Arial | calc(1.375rem + 1.5vw) | 700 |
| Heading 2 | Arial | .875rem | 700 |
| Heading 3 | Arial | 12px | 700 |
| Body | inherit | var(--bs-body-font-size) | 400 |
| Caption | inherit | 1em | 400 |

**Typographic Rules:**
- Limit to 2 font families max per screen
- Use **Arial** for body/UI text, **inherit** for display/headings
- Maintain consistent hierarchy: no more than 3-4 font sizes per screen
- Headings use bold (600-700), body uses regular (400)
- Line height: 1.5 for body text, 1.2 for headings
- Use color and opacity for secondary hierarchy, not additional font sizes


---

## 4. Component Stylings

No components detected. Scan `src/components/` or `components/` to populate this section.

---

## 5. Layout Principles

- **Base spacing unit:** 5px
- **Spacing scale:** 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60
- **Border radius:** 0 0 calc(.25rem - 1px) calc(.25rem - 1px), .2rem, .25rem, .25em, .3rem, 1rem, 2em, calc(.25rem - 1px), calc(.25rem - 1px) calc(.25rem - 1px)0 0, inherit, calc(.3rem - 1px), 2px, 3px, 4px, 5px, 50rem
- **Max content width:** 991px

**Spacing as Meaning:**
| Spacing | Use |
|---|---|
| 2.5-5px | Tight: related items within a group |
| 10px | Medium: between groups |
| 15-20px | Wide: between sections |
| 30px+ | Vast: major section breaks |


---

## 6. Depth & Elevation

### Flat — subtle depth hints

- `0 0 0 1px #fff,0 0 0 .25rem rgba(13,110,253,.25)`
- `inset 0-1px 0 rgba(0,0,0,.125)`
- `0 0 1px rgba(0,0,0,.5)`

### Raised — cards, buttons, interactive elements

- `0 0 0 .25rem rgba(13,110,253,.25)`
- `0 0 0 .25rem rgba(25,135,84,.25)`
- `0 0 0 .25rem rgba(220,53,69,.25)`

### Overlay — full-screen overlays, top-level dialogs

- `inset 0 0 0 9999px var(--bs-table-accent-bg)`
- `inset -30px 1px 30px -16px #eee`

### Z-Index Scale

`0, 1, 2, 3, 5, 1000, 1020, 1030, 1040, 1045, 1050, 1055, 1070, 1080, 10001`



---

## 7. Animation & Motion

This project uses **expressive motion**. Animations are an integral part of the experience.

### CSS Animations

- `@keyframes progress-bar-stripes`
- `@keyframes spinner-border`
- `@keyframes spinner-grow`
- `@keyframes placeholder-glow`
- `@keyframes placeholder-wave`
- `@keyframes placeHolderShimmer`

### Motion Guidelines

- Duration: 150-300ms for micro-interactions, 300-500ms for page transitions
- Easing: `ease-out` for enters, `ease-in` for exits
- Always respect `prefers-reduced-motion`


---

## 8. Do's and Don'ts

### Do's

- Use `#000000` as the primary page background
- Pair **Arial** (body) with **inherit** (display) — these are the only allowed fonts
- Follow the **5px** spacing grid for all margins, padding, and gaps
- Use the defined shadow tokens for elevation — see Section 6
- Use border-radius from the scale: 0 0 calc(.25rem - 1px) calc(.25rem - 1px), .2rem, .25rem, .25em, .3rem

### Don'ts

- Don't introduce colors outside this palette — extend the design tokens first
- Don't introduce additional font families beyond Arial and inherit
- Don't use arbitrary spacing values — stick to multiples of 5px
- Don't create custom box-shadow values outside the system tokens
- Don't use arbitrary border-radius values — pick from the defined scale
- Don't use backdrop-blur or blur effects

### Anti-Patterns (detected from codebase)

- No blur or backdrop-blur effects
- No zebra striping on tables/lists


---

## 9. Responsive Behavior

| Name | Value | Source |
|---|---|---|
| breakpoint-576px | 576px | css |
| breakpoint-768px | 768px | css |
| breakpoint-992px | 992px | css |
| breakpoint-1200px | 1200px | css |
| breakpoint-1400px | 1400px | css |

**Approach:** Use `@media (min-width: ...)` queries matching the breakpoints above.


---

## 10. Agent Prompt Guide

Use these as starting points when building new UI:

### Build a Card

```
Background: #212529
Border: 1px solid #5c636a
Radius: calc(.25rem - 1px) calc(.25rem - 1px)0 0
Padding: 20px
Font: Arial
Use shadow tokens from Section 6.
```

### Build a Button

```
Primary: bg var(--accent), text white
Ghost: bg transparent, border #5c636a
Padding: 10px 20px
Radius: calc(.25rem - 1px) calc(.25rem - 1px)0 0
Hover: opacity 0.9 or lighter shade
Focus: ring with var(--accent)
```

### Build a Page Layout

```
Background: #000000
Max-width: 991px, centered
Grid: 5px base
Responsive: mobile-first, breakpoints from Section 9
```

### Build a Stats Card

```
Surface: #212529
Label: #6c757d (muted, 12px, uppercase)
Value: #ffffff (primary, 24-32px, bold)
Status: use success/warning/danger from Section 2
```

### Build a Form

```
Input bg: #000000
Input border: 1px solid #5c636a
Focus: border-color var(--accent)
Label: #6c757d 12px
Spacing: 20px between fields
Radius: calc(.25rem - 1px) calc(.25rem - 1px)0 0
```

### General Component

```
1. Read DESIGN.md Sections 2-6 for tokens
2. Colors: only from palette
3. Font: Arial, type scale from Section 3
4. Spacing: 5px grid
5. Components: match patterns from Section 4
6. Elevation: shadow tokens
```

---
name: topcv-design
description: Design system skill for topcv. Activate when building UI components, pages, or any visual elements. Provides exact color tokens, typography scale, spacing grid, component patterns, and craft rules. Read references/DESIGN.md before writing any CSS or JSX.
---

# topcv Design System

You are building UI for **topcv**. Dark-themed, neutral palette, sans-serif typography (Arial), standard density on a 5px grid, expressive motion.

## Design Philosophy

- **Layered depth** — use shadow tokens to create a sense of physical layering. Each elevation level has a specific shadow.
- **Gradient accents** — gradients are used thoughtfully for emphasis, not decoration.
- **Type pairing** — Arial for body/UI text, inherit for headings/display. Never introduce a third typeface.
- **standard density** — 5px base grid. Every dimension is a multiple of 5.
- **neutral palette** — the color temperature runs neutral, matching the sans-serif typography.
- **Expressive motion** — animations are an integral part of the experience. Use spring physics and layout animations.

## Color System

### Core Palette

| Role | Token | Hex | Use |
|------|-------|-----|-----|
| Background | `--background` | `#000000` | Page/app background |
| Surface | `--surface` | `#212529` | Cards, panels, modals |
| Text Primary | `--text-primary` | `#ffffff` | Headings, body text |
| Text Muted | `--text-muted` | `#6c757d` | Captions, placeholders |
| Border | `--border` | `#5c636a` | Dividers, card borders |

### Status Colors

| Status | Hex | Use |
|--------|-----|-----|
| Success | `#00b14f` | Confirmations, positive trends |
| Warning | `#ffc107` | Caution states, pending items |
| Danger | `#dc3545` | Errors, destructive actions |

### Extended Palette

- **bs-primary:** `#0d6efd`
- `#198754`
- `#dee2e6` — Light surface or highlight color
- `#e9ecef` — Light surface or highlight color
- `#0dcaf0`
- `#0a58ca`
- `#999999`
- `#41464b`

### CSS Variable Tokens

```css
--bs-primary: #0d6efd;
--bs-secondary: #6c757d;
--bs-primary-rgb: 13,110,253;
--bs-secondary-rgb: 108,117,125;
--bs-table-accent-bg: transparent;
```

## Typography

### Font Stack

- **Arial** — Heading 1, Heading 2, Heading 3
- **inherit** — Body, Caption

### Type Scale

| Role | Family | Size | Weight |
|------|--------|------|--------|
| Heading 1 | Arial | calc(1.375rem + 1.5vw) | 700 |
| Heading 2 | Arial | .875rem | 700 |
| Heading 3 | Arial | 12px | 700 |
| Body | inherit | var(--bs-body-font-size) | 400 |
| Caption | inherit | 1em | 400 |

### Typography Rules

- Body/UI: **Arial**, Headings: **inherit** — these are the only display fonts
- Max 3-4 font sizes per screen
- Headings: weight 600-700, body: weight 400
- Use color and opacity for text hierarchy, not additional font sizes
- Line height: 1.5 for body, 1.2 for headings

## Spacing & Layout

### Base Grid: 5px

Every dimension (margin, padding, gap, width, height) must be a multiple of **5px**.

### Spacing Scale

`5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60` px

### Spacing as Meaning

| Spacing | Use |
|---------|-----|
| 2.5-5px | Tight: related items within a group |
| 10px | Medium: between groups |
| 15-20px | Wide: between sections |
| 30px+ | Vast: major section breaks |

### Border Radius

Scale: `0 0 calc(.25rem - 1px) calc(.25rem - 1px), .2rem, .25rem, .25em, .3rem, 1rem, 2em, calc(.25rem - 1px), calc(.25rem - 1px) calc(.25rem - 1px)0 0, inherit, calc(.3rem - 1px), 2px, 3px, 4px, 5px, 50rem`
Default: `calc(.25rem - 1px) calc(.25rem - 1px)0 0`

### Container

Max-width: `991px`, centered with auto margins.

### Breakpoints

| Name | Value |
|------|-------|
| breakpoint-576px | 576px |
| breakpoint-768px | 768px |
| breakpoint-992px | 992px |
| breakpoint-1200px | 1200px |
| breakpoint-1400px | 1400px |

Mobile-first: design for small screens, layer on responsive overrides.

## Component Patterns

### Card

```css
.card {
  background: #212529;
  border: 1px solid #5c636a;
  border-radius: calc(.25rem - 1px) calc(.25rem - 1px)0 0;
  padding: 20px;
  box-shadow: 0 0 0 .25rem rgba(13,110,253,.25);
}
```

```html
<div class="card">
  <h3>Card Title</h3>
  <p>Card content goes here.</p>
</div>
```

### Button

```css
/* Primary */
.btn-primary {
  background: #444444;
  color: #ffffff;
  border-radius: calc(.25rem - 1px) calc(.25rem - 1px)0 0;
  padding: 10px 20px;
  font-weight: 500;
  transition: opacity 150ms ease;
}
.btn-primary:hover { opacity: 0.9; }

/* Ghost */
.btn-ghost {
  background: transparent;
  border: 1px solid #5c636a;
  color: #ffffff;
  border-radius: calc(.25rem - 1px) calc(.25rem - 1px)0 0;
  padding: 10px 20px;
}
```

```html
<button class="btn-primary">Get Started</button>
<button class="btn-ghost">Learn More</button>
```

### Input

```css
.input {
  background: #000000;
  border: 1px solid #5c636a;
  border-radius: calc(.25rem - 1px) calc(.25rem - 1px)0 0;
  padding: 10px 15px;
  color: #ffffff;
  font-size: 14px;
}
.input:focus { border-color: var(--accent); outline: none; }
```

```html
<input class="input" type="text" placeholder="Search..." />
```

### Badge / Chip

```css
.badge {
  display: inline-flex;
  align-items: center;
  padding: 5px 10px;
  border-radius: 9999px;
  font-size: 12px;
  font-weight: 500;
  background: #212529;
  color: #6c757d;
}
```

```html
<span class="badge">New</span>
<span class="badge">Beta</span>
```

### Modal / Dialog

```css
.modal-backdrop { background: rgba(0, 0, 0, 0.6); }
.modal {
  background: #212529;
  border: 1px solid #5c636a;
  border-radius: 50rem;
  padding: 30px;
  max-width: 480px;
  width: 90vw;
  box-shadow: inset 0 0 0 9999px var(--bs-table-accent-bg);
}
```

```html
<div class="modal-backdrop">
  <div class="modal">
    <h2>Dialog Title</h2>
    <p>Dialog content.</p>
    <button class="btn-primary">Confirm</button>
    <button class="btn-ghost">Cancel</button>
  </div>
</div>
```

### Table

```css
.table { width: 100%; border-collapse: collapse; }
.table th {
  text-align: left;
  padding: 10px 15px;
  font-weight: 500;
  font-size: 12px;
  color: #6c757d;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  border-bottom: 1px solid #5c636a;
}
.table td {
  padding: 15px;
  border-bottom: 1px solid #5c636a;
}
```

```html
<table class="table">
  <thead><tr><th>Name</th><th>Status</th><th>Date</th></tr></thead>
  <tbody>
    <tr><td>Item One</td><td>Active</td><td>Jan 1</td></tr>
    <tr><td>Item Two</td><td>Pending</td><td>Jan 2</td></tr>
  </tbody>
</table>
```

### Navigation

```css
.nav {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 15px 20px;
  border-bottom: 1px solid #5c636a;
}
.nav-link {
  color: #6c757d;
  padding: 10px 15px;
  border-radius: calc(.25rem - 1px) calc(.25rem - 1px)0 0;
  transition: color 150ms;
}
.nav-link:hover { color: #ffffff; }
```

```html
<nav class="nav">
  <a href="/" class="nav-link active">Home</a>
  <a href="/about" class="nav-link">About</a>
  <a href="/pricing" class="nav-link">Pricing</a>
  <button class="btn-primary" style="margin-left: auto">Get Started</button>
</nav>
```

## Animation & Motion

This project uses **expressive motion**. Animations are part of the design language.

### CSS Animations

- `progress-bar-stripes`
- `spinner-border`
- `spinner-grow`
- `placeholder-glow`
- `placeholder-wave`

### Motion Tokens

- **Duration scale:** `150ms`
- **Easing functions:** `ease-in-out`
- **Animated properties:** `border-color`, `box-shadow`

### Motion Guidelines

- **Duration:** Use values from the duration scale above. Short (150ms) for micro-interactions, long (150ms) for page transitions
- **Easing:** Use `ease-in-out` as the default easing curve
- **Direction:** Elements enter from bottom/right, exit to top/left
- **Reduced motion:** Always respect `prefers-reduced-motion` — disable animations when set

## Depth & Elevation

### Shadow Tokens

- Subtle: `0 0 0 1px #fff,0 0 0 .25rem rgba(13,110,253,.25)`
- Subtle: `inset 0-1px 0 rgba(0,0,0,.125)`
- Subtle: `0 0 1px rgba(0,0,0,.5)`
- Raised (cards, buttons): `0 0 0 .25rem rgba(13,110,253,.25)`
- Raised (cards, buttons): `0 0 0 .25rem rgba(25,135,84,.25)`
- Raised (cards, buttons): `0 0 0 .25rem rgba(220,53,69,.25)`

### Z-Index Scale

`0, 1, 2, 3, 5, 1000, 1020, 1030, 1040, 1045, 1050, 1055, 1070, 1080, 10001`

Use these exact values — never invent z-index values.

## Anti-Patterns (Never Do)

- **No blur effects** — no backdrop-blur, no filter: blur()
- **No zebra striping** — tables and lists use borders for separation
- **No invented colors** — every hex value must come from the palette above
- **No arbitrary spacing** — every dimension is a multiple of 5px
- **No extra fonts** — only Arial and inherit are allowed
- **No arbitrary border-radius** — use the scale: .2rem, .25rem, .25em, .3rem, 1rem, 2em, 2px, 3px, 4px, 5px
- **No opacity for disabled states** — use muted colors instead

## Workflow

1. **Read** `references/DESIGN.md` before writing any UI code
2. **Pick colors** from the Color System section — never invent new ones
3. **Set typography** — Arial, inherit only, using the type scale
4. **Build layout** on the 5px grid — check every margin, padding, gap
5. **Match components** to patterns above before creating new ones
6. **Apply elevation** — use shadow tokens
7. **Validate** — every value traces back to a design token. No magic numbers.

## Brand Spec

- **Brand typeface:** Arial

## Quick Reference

```
Background:     #000000
Surface:        #212529
Text:           #ffffff / #6c757d
Accent:         (not extracted)
Border:         #5c636a
Font:           Arial
Spacing:        5px grid
Radius:         calc(.25rem - 1px) calc(.25rem - 1px)0 0
Components:     0 detected
```

## When to Trigger

Activate this skill when:
- Creating new components, pages, or visual elements for topcv
- Writing CSS, Tailwind classes, styled-components, or inline styles
- Building page layouts, templates, or responsive designs
- Reviewing UI code for design consistency
- The user mentions "topcv" design, style, UI, or theme
- Generating mockups, wireframes, or visual prototypes

---

# Full Reference Files

> Every output file is embedded below. Claude has full design system context from /skills alone.

## Design System Tokens (DESIGN.md)

# topcv DESIGN.md

> Auto-generated design system — reverse-engineered via static analysis by skillui.
> Frameworks: None detected
> Colors: 20 · Fonts: 2 · Components: 0
> Icon library: not detected · State: not detected
> Primary theme: dark · Dark mode toggle: no · Motion: expressive

---

## 1. Visual Theme & Atmosphere

This is a **dark-themed** interface with a neutral tone. Depth is expressed through layered shadows and subtle surface color variation. Typography pairs **inherit** for display/headings with **Arial** for body text, creating clear visual hierarchy through type contrast. Spacing follows a **5px base grid** (standard density), with scale: 5, 10, 15, 20, 25, 30, 35, 40px. Motion is expressive — spring physics, layout animations, and staggered reveals are part of the visual language.

---

## 2. Color Palette & Roles

| Token | Hex | Role | Use |
|---|---|---|---|
| bs-table-striped-color | `#000000` | background | Page background, darkest surface |
| bs-body-color | `#212529` | surface | Card and panel backgrounds |
| bs-table-striped-color | `#ffffff` | text-primary | Headings and body text |
| bs-secondary | `#6c757d` | text-muted | Captions, placeholders, secondary info |
| border | `#5c636a` | border | Dividers, card borders, outlines |
| danger | `#dc3545` | danger | Error states, destructive actions |
| success | `#00b14f` | success | Success states, positive indicators |
| warning | `#ffc107` | warning | Warning states, caution indicators |
| bs-primary | `#0d6efd` | info | Informational highlights |
| unknown | `#198754` | unknown | Palette color |
| unknown | `#dee2e6` | unknown | Palette color |
| unknown | `#e9ecef` | unknown | Palette color |
| unknown | `#0dcaf0` | unknown | Palette color |
| unknown | `#0a58ca` | unknown | Palette color |
| unknown | `#999999` | unknown | Palette color |
| unknown | `#41464b` | unknown | Palette color |
| unknown | `#51585e` | unknown | Palette color |
| unknown | `#191c1f` | unknown | Palette color |
| unknown | `#373b3e` | unknown | Palette color |
| unknown | `#adb5bd` | unknown | Palette color |

### CSS Variable Tokens

```css
--bs-primary: #0d6efd;
--bs-secondary: #6c757d;
--bs-primary-rgb: 13,110,253;
--bs-secondary-rgb: 108,117,125;
--bs-table-accent-bg: transparent;
```


---

## 3. Typography Rules

**Font Stack:**
- **Arial** — Heading 1, Heading 2, Heading 3
- **inherit** — Body, Caption

| Role | Font | Size | Weight |
|---|---|---|---|
| Heading 1 | Arial | calc(1.375rem + 1.5vw) | 700 |
| Heading 2 | Arial | .875rem | 700 |
| Heading 3 | Arial | 12px | 700 |
| Body | inherit | var(--bs-body-font-size) | 400 |
| Caption | inherit | 1em | 400 |

**Typographic Rules:**
- Limit to 2 font families max per screen
- Use **Arial** for body/UI text, **inherit** for display/headings
- Maintain consistent hierarchy: no more than 3-4 font sizes per screen
- Headings use bold (600-700), body uses regular (400)
- Line height: 1.5 for body text, 1.2 for headings
- Use color and opacity for secondary hierarchy, not additional font sizes


---

## 4. Component Stylings

No components detected. Scan `src/components/` or `components/` to populate this section.

---

## 5. Layout Principles

- **Base spacing unit:** 5px
- **Spacing scale:** 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60
- **Border radius:** 0 0 calc(.25rem - 1px) calc(.25rem - 1px), .2rem, .25rem, .25em, .3rem, 1rem, 2em, calc(.25rem - 1px), calc(.25rem - 1px) calc(.25rem - 1px)0 0, inherit, calc(.3rem - 1px), 2px, 3px, 4px, 5px, 50rem
- **Max content width:** 991px

**Spacing as Meaning:**
| Spacing | Use |
|---|---|
| 2.5-5px | Tight: related items within a group |
| 10px | Medium: between groups |
| 15-20px | Wide: between sections |
| 30px+ | Vast: major section breaks |


---

## 6. Depth & Elevation

### Flat — subtle depth hints

- `0 0 0 1px #fff,0 0 0 .25rem rgba(13,110,253,.25)`
- `inset 0-1px 0 rgba(0,0,0,.125)`
- `0 0 1px rgba(0,0,0,.5)`

### Raised — cards, buttons, interactive elements

- `0 0 0 .25rem rgba(13,110,253,.25)`
- `0 0 0 .25rem rgba(25,135,84,.25)`
- `0 0 0 .25rem rgba(220,53,69,.25)`

### Overlay — full-screen overlays, top-level dialogs

- `inset 0 0 0 9999px var(--bs-table-accent-bg)`
- `inset -30px 1px 30px -16px #eee`

### Z-Index Scale

`0, 1, 2, 3, 5, 1000, 1020, 1030, 1040, 1045, 1050, 1055, 1070, 1080, 10001`



---

## 7. Animation & Motion

This project uses **expressive motion**. Animations are an integral part of the experience.

### CSS Animations

- `@keyframes progress-bar-stripes`
- `@keyframes spinner-border`
- `@keyframes spinner-grow`
- `@keyframes placeholder-glow`
- `@keyframes placeholder-wave`
- `@keyframes placeHolderShimmer`

### Motion Guidelines

- Duration: 150-300ms for micro-interactions, 300-500ms for page transitions
- Easing: `ease-out` for enters, `ease-in` for exits
- Always respect `prefers-reduced-motion`


---

## 8. Do's and Don'ts

### Do's

- Use `#000000` as the primary page background
- Pair **Arial** (body) with **inherit** (display) — these are the only allowed fonts
- Follow the **5px** spacing grid for all margins, padding, and gaps
- Use the defined shadow tokens for elevation — see Section 6
- Use border-radius from the scale: 0 0 calc(.25rem - 1px) calc(.25rem - 1px), .2rem, .25rem, .25em, .3rem

### Don'ts

- Don't introduce colors outside this palette — extend the design tokens first
- Don't introduce additional font families beyond Arial and inherit
- Don't use arbitrary spacing values — stick to multiples of 5px
- Don't create custom box-shadow values outside the system tokens
- Don't use arbitrary border-radius values — pick from the defined scale
- Don't use backdrop-blur or blur effects

### Anti-Patterns (detected from codebase)

- No blur or backdrop-blur effects
- No zebra striping on tables/lists


---

## 9. Responsive Behavior

| Name | Value | Source |
|---|---|---|
| breakpoint-576px | 576px | css |
| breakpoint-768px | 768px | css |
| breakpoint-992px | 992px | css |
| breakpoint-1200px | 1200px | css |
| breakpoint-1400px | 1400px | css |

**Approach:** Use `@media (min-width: ...)` queries matching the breakpoints above.


---

## 10. Agent Prompt Guide

Use these as starting points when building new UI:

### Build a Card

```
Background: #212529
Border: 1px solid #5c636a
Radius: calc(.25rem - 1px) calc(.25rem - 1px)0 0
Padding: 20px
Font: Arial
Use shadow tokens from Section 6.
```

### Build a Button

```
Primary: bg var(--accent), text white
Ghost: bg transparent, border #5c636a
Padding: 10px 20px
Radius: calc(.25rem - 1px) calc(.25rem - 1px)0 0
Hover: opacity 0.9 or lighter shade
Focus: ring with var(--accent)
```

### Build a Page Layout

```
Background: #000000
Max-width: 991px, centered
Grid: 5px base
Responsive: mobile-first, breakpoints from Section 9
```

### Build a Stats Card

```
Surface: #212529
Label: #6c757d (muted, 12px, uppercase)
Value: #ffffff (primary, 24-32px, bold)
Status: use success/warning/danger from Section 2
```

### Build a Form

```
Input bg: #000000
Input border: 1px solid #5c636a
Focus: border-color var(--accent)
Label: #6c757d 12px
Spacing: 20px between fields
Radius: calc(.25rem - 1px) calc(.25rem - 1px)0 0
```

### General Component

```
1. Read DESIGN.md Sections 2-6 for tokens
2. Colors: only from palette
3. Font: Arial, type scale from Section 3
4. Spacing: 5px grid
5. Components: match patterns from Section 4
6. Elevation: shadow tokens
```

## Homepage Screenshots (screenshots/)

![homepage.png](screenshots/homepage.png)

